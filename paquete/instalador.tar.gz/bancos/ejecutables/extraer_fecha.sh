filename=$1
echo "${filename#*_}"
